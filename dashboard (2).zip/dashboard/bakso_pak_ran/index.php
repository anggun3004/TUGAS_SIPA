<?php
include 'koneksi.php';

$query  = "SELECT * FROM produk";
$result = mysqli_query($connect, $query);
?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Bakso Pak Ran - Bakso Hangat, Kenyal & Nikmat</title>
  <meta name="description" content="Bakso Pak Ran: bakso urat, bakso beranak, dan bakso mercon.">

  <!-- BOOTSTRAP 5 -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

  <!-- BOOTSTRAP ICONS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">

  <!-- GOOGLE FONT -->
  <link href="https://fonts.googleapis.com/css2?family=Baloo+2:wght@500;700;800&family=Nunito:wght@400;600;700&display=swap" rel="stylesheet">

  <!-- CSS EKSTERNAL -->
  <link href="style.css" rel="stylesheet">
  <link href="dashboard" rel="stylesheet">
</head>

<body>

<!-- ===================================== -->
<!-- NAVBAR -->
<!-- ===================================== -->

<nav class="navbar navbar-expand-lg fixed-top navbar-bakso">
  <div class="container">

    <a class="navbar-brand brand" href="#home">
      Bakso <span>Pak Ran</span>
    </a>

    <button class="navbar-toggler" type="button"
      data-bs-toggle="collapse"
      data-bs-target="#nav"
      aria-label="Buka navigasi">
      <i class="bi bi-list fs-1 text-white"></i>
    </button>

    <div class="collapse navbar-collapse" id="nav">
      <ul class="navbar-nav ms-auto align-items-lg-center gap-lg-2">

        <li class="nav-item">
          <a class="nav-link" href="#home">Home</a>
        </li>

        <li class="nav-item">
          <a class="nav-link" href="#about">Tentang Makanan</a>
        </li>

        <li class="nav-item">
          <a class="nav-link" href="#menu">Menu</a>
        </li>

        <li class="nav-item">
          <a class="nav-link" href="#pesan">Pesanan</a>
        </li>

        <li class="nav-item">
          <a class="btn btn-warning fw-bold rounded-pill px-4 ms-lg-2" href="#pesan">
            <i class="bi bi-bag-heart"></i>
            Pesan
            <span class="badge bg-danger" id="navCount">0</span>
          </a>
        </li>

      </ul>
    </div>
  </div>
</nav>


<!-- ===================================== -->
<!-- HOME -->
<!-- ===================================== -->

<header id="home" class="hero">

  <div class="steam s1"></div>
  <div class="steam s2"></div>
  <div class="steam s3"></div>

  <div class="container">
    <div class="row align-items-center g-5">

      <div class="col-lg-6 text-center text-lg-start">

        <span class="badge-pill">
          Panas, Kenyal, Bikin Nagih
        </span>

        <h1 class="hero-title">
          Bakso <span class="hl">Pak Ran</span>
        </h1>

        <p class="lead hero-text">
          Kuah kaldu sapi yang gurih, bakso urat yang kenyal,
          dan sambal yang pedasnya pas. Dimasak segar setiap hari,
          diantar sampai depan pintu rumahmu.
        </p>

        <div class="d-flex flex-wrap gap-3 justify-content-center justify-content-lg-start">

          <a href="#menu" class="btn btn-lg btn-warning fw-bold rounded-pill px-4 shadow">
            <i class="bi bi-journal-richtext"></i>
            Lihat Menu
          </a>

          <a href="#pesan" class="btn btn-lg btn-light fw-bold rounded-pill px-4 shadow">
            <i class="bi bi-scooter"></i>
            Pesan Sekarang
          </a>

        </div>

        <div class="row mt-5 text-center text-lg-start g-3">

          <div class="col-4">
            <div class="stat">10+</div>
            <small>Tahun Berjualan</small>
          </div>

          <div class="col-4">
            <div class="stat">50rb+</div>
            <small>Mangkuk Terjual</small>
          </div>

          <div class="col-4">
            <div class="stat">4.9/5</div>
            <small>Rating Pelanggan</small>
          </div>

        </div>
      </div>

      <div class="col-lg-6 text-center">
        <div class="hero-photo">
          <img
            src="https://commons.wikimedia.org/wiki/Special:FilePath/Semangkuk%20bakso.jpg"
            alt="Foto asli semangkuk bakso">
        </div>
      </div>

    </div>
  </div>

  <svg class="wave" viewBox="0 0 1440 120" preserveAspectRatio="none">
    <path fill="#FFFFFF"
      d="M0,64L60,69.3C120,75,240,85,360,80C480,75,600,53,720,48C840,43,960,53,1080,64C1200,75,1320,85,1380,90.7L1440,96L1440,120L0,120Z"/>
  </svg>

</header>


<!-- ===================================== -->
<!-- TENTANG MAKANAN -->
<!-- ===================================== -->

<section id="about" class="py-5 section-cream">
  <div class="container py-4">

    <div class="text-center mb-5">

      <span class="section-tag">Tentang Makanan</span>

      <h2 class="section-title">
        Kenapa Bakso Pak Ran Beda?
      </h2>

      <p class="text-muted mx-auto" style="max-width:640px">
        Bakso adalah makanan khas Indonesia berupa bola daging
        yang disajikan dalam kuah kaldu hangat. Di Bakso Pak Ran,
        resep keluarga dijaga dari generasi ke generasi.
      </p>

    </div>

    <div class="row g-4 align-items-center mb-5">

      <!-- CERITA PAK RAN -->
      <div class="col-lg-5">

        <div class="about-card">

          <img
            src="https://commons.wikimedia.org/wiki/Special:FilePath/Bakso%20Urat.jpg"
            class="about-photo"
            alt="Foto bakso urat">

          <h4>Cerita Pak Ran</h4>

          <p>
            Berawal dari gerobak kecil di pinggir jalan, Pak Ran membangun
            usaha bakso dengan niat mencari rezeki yang halal dan penuh berkah.
            Setiap bakso dibuat menggunakan bahan-bahan pilihan yang halal
            dan diolah dengan penuh tanggung jawab. Pak Ran percaya bahwa
            berdagang bukan hanya tentang mendapatkan keuntungan, tetapi juga
            tentang kejujuran, menjaga kebersihan, serta memberikan makanan
            terbaik kepada pelanggan sebagai bentuk rasa syukur kepada Allah SWT.
          </p>

          <p class="mb-0">
            Sekarang Bakso Pak Ran bisa dinikmati di rumah
            lewat layanan ojek online dan delivery.
          </p>

        </div>
      </div>


      <!-- KEUNGGULAN -->
      <div class="col-lg-7">

        <div class="row g-4">

          <div class="col-sm-6">
            <div class="feature">

              <div class="icon">
                <i class="bi bi-egg-fried"></i>
              </div>

              <h5>Daging Sapi Pilihan</h5>

              <p>
                Digiling segar tiap pagi, kadar daging tinggi
                sehingga kenyal dan juicy.
              </p>

            </div>
          </div>


          <div class="col-sm-6">
            <div class="feature">

              <div class="icon">
                <i class="bi bi-droplet-half"></i>
              </div>

              <h5>Kuah Kaldu Asli</h5>

              <p>
                Direbus dari tulang sumsum sapi,
                tanpa bumbu instan berlebihan.
              </p>

            </div>
          </div>


          <div class="col-sm-6">
            <div class="feature">

              <div class="icon">
                <i class="bi bi-shield-check"></i>
              </div>

              <h5>Higienis & Halal</h5>

              <p>
                Dimasak bersih, menggunakan bahan halal
                dan menjaga kebersihan makanan.
              </p>

            </div>
          </div>


          <div class="col-sm-6">
            <div class="feature">

              <div class="icon">
                <i class="bi bi-heart"></i>
              </div>

              <h5>Kejujuran Berdagang</h5>

              <p>
                Mengutamakan kejujuran, tanggung jawab,
                dan pelayanan yang ramah kepada pelanggan.
              </p>

            </div>
          </div>

        </div>
      </div>
    </div>


    <!-- CARA PEMESANAN -->
    <div class="row g-4 text-center">

      <div class="col-md-4">
        <div class="step">
          <span>1</span>
          <h6>Pilih Menu</h6>
          <p>Pilih bakso favoritmu dari daftar menu.</p>
        </div>
      </div>

      <div class="col-md-4">
        <div class="step">
          <span>2</span>
          <h6>Isi Data Pemesan</h6>
          <p>Isi nama, alamat, dan metode pengantaran.</p>
        </div>
      </div>

      <div class="col-md-4">
        <div class="step">
          <span>3</span>
          <h6>Bakso Datang!</h6>
          <p>Tunggu di rumah, bakso panas segera tiba.</p>
        </div>
      </div>

    </div>

  </div>
</section>


<!-- ===================================== -->
<!-- MENU MAKANAN DAN MINUMAN -->
<!-- FOTO LANGSUNG DI HTML -->
<!-- ===================================== -->

<section id="menu" class="py-5 section-white">
  <div class="container py-4">

    <div class="text-center mb-4">

      <span class="section-tag">Menu Kami</span>

      <h2 class="section-title">
        Pilih Bakso Favoritmu
      </h2>

      <p class="text-muted">
        Berbagai pilihan makanan dan minuman untuk menemani harimu.
      </p>

    </div>


    <!-- FILTER MENU -->
    <div class="d-flex flex-wrap justify-content-center gap-2 mb-4" id="filters">

      <button class="btn btn-filter active" data-cat="semua">
        Semua
      </button>

      <button class="btn btn-filter" data-cat="bakso">
        Bakso
      </button>

      <button class="btn btn-filter" data-cat="tambahan">
        Tambahan
      </button>

      <button class="btn btn-filter" data-cat="minuman">
        Minuman
      </button>

    </div>


    <!-- DAFTAR MENU -->
    <div class="row g-4" id="menuList">


      <!-- MENU 1: BAKSO URAT -->
      <div class="col-sm-6 col-lg-4 col-xl-3 menu-item"
        data-id="1" data-cat="bakso">

        <div class="menu-card d-flex flex-column">

          <div class="menu-img">
            <img
              src="images/bakso.jpg"
              alt="Bakso Urat Jumbo"
              loading="lazy">

            <span class="menu-tag">Best Seller</span>
          </div>

          <div class="p-3 d-flex flex-column flex-grow-1">

            <h5 class="fw-bold">Bakso Urat Jumbo</h5>

            <p>
              Bakso besar isi urat sapi, kenyal dan gurih,
              lengkap mie dan sayur.
            </p>

            <div class="d-flex justify-content-between align-items-center mt-auto">
              <span class="price">Rp 20.000</span>
              <div class="qty-slot"></div>
            </div>

          </div>
        </div>
      </div>


      <!-- MENU 2: BAKSO BERANAK -->
      <div class="col-sm-6 col-lg-4 col-xl-3 menu-item"
        data-id="2" data-cat="bakso">

        <div class="menu-card d-flex flex-column">

          <div class="menu-img">
            <img
              src="https://warna-cloudinary.b-cdn.net/ungu/opt-45ba1c103755f2e3e1eec0c4e3f510ea.jpg"
              alt="Bakso Beranak"
              loading="lazy">

            <span class="menu-tag">Favorit</span>
          </div>

          <div class="p-3 d-flex flex-column flex-grow-1">

            <h5 class="fw-bold">Bakso Beranak</h5>

            <p>
              Satu bakso besar berisi bakso-bakso kecil di dalamnya.
            </p>

            <div class="d-flex justify-content-between align-items-center mt-auto">
              <span class="price">Rp 25.000</span>
              <div class="qty-slot"></div>
            </div>

          </div>
        </div>
      </div>


      <!-- MENU 3: BAKSO MERCON -->
      <div class="col-sm-6 col-lg-4 col-xl-3 menu-item"
        data-id="3" data-cat="bakso">

        <div class="menu-card d-flex flex-column">

          <div class="menu-img">
            <img src="images/bakso.jpg"
                 alt="Bakso Mercon"
                 loading="lazy">

            <span class="menu-tag">Pedas</span>
          </div>

          <div class="p-3 d-flex flex-column flex-grow-1">

            <h5 class="fw-bold">Bakso Mercon</h5>

            <p>
              Bakso isi cabai rawit dengan rasa pedas yang menggugah selera.
            </p>

            <div class="d-flex justify-content-between align-items-center mt-auto">
              <span class="price">Rp 22.000</span>
              <div class="qty-slot"></div>
            </div>

          </div>
        </div>
      </div>


      <!-- MENU 4: BAKSO TELUR -->
      <div class="col-sm-6 col-lg-4 col-xl-3 menu-item"
        data-id="4" data-cat="bakso">

        <div class="menu-card d-flex flex-column">

          <div class="menu-img">
            <img
              src="https://akcdn.detik.net.id/visual/2020/02/05/7e1cf566-92db-4050-91ec-e1a3bb6d127a_169.jpeg?q=90&w=750"
              alt="Bakso Telur"
              loading="lazy">
          </div>

          <div class="p-3 d-flex flex-column flex-grow-1">

            <h5 class="fw-bold">Bakso Telur</h5>

            <p>
              Bakso lembut dengan telur puyuh utuh di tengahnya.
            </p>

            <div class="d-flex justify-content-between align-items-center mt-auto">
              <span class="price">Rp 18.000</span>
              <div class="qty-slot"></div>
            </div>

          </div>
        </div>
      </div>


      <!-- MENU 5: BAKSO HALUS -->
      <div class="col-sm-6 col-lg-4 col-xl-3 menu-item"
        data-id="5" data-cat="bakso">

        <div class="menu-card d-flex flex-column">

          <div class="menu-img">
           
          </div>

          <div class="p-3 d-flex flex-column flex-grow-1">

            <h5 class="fw-bold">Bakso Halus Kuah</h5>

            <p>
              Bakso halus lembut dengan kuah kaldu gurih.
            </p>

            <div class="d-flex justify-content-between align-items-center mt-auto">
              <span class="price">Rp 15.000</span>
              <div class="qty-slot"></div>
            </div>

          </div>
        </div>
      </div>


      <!-- MENU 6: MIE AYAM BAKSO -->
      <div class="col-sm-6 col-lg-4 col-xl-3 menu-item"
        data-id="6" data-cat="bakso">

        <div class="menu-card d-flex flex-column">

          <div class="menu-img">
            <img
              src="https://images.unsplash.com/photo-1569718212165-3a8278d5f624"
              alt="Mie Ayam Bakso"
              loading="lazy">
          </div>

          <div class="p-3 d-flex flex-column flex-grow-1">

            <h5 class="fw-bold">Mie Ayam Bakso</h5>

            <p>
              Mie ayam gurih dengan topping bakso dan pangsit.
            </p>

            <div class="d-flex justify-content-between align-items-center mt-auto">
              <span class="price">Rp 20.000</span>
              <div class="qty-slot"></div>
            </div>

          </div>
        </div>
      </div>


      <!-- MENU 7: PANGSIT GORENG -->
      <div class="col-sm-6 col-lg-4 col-xl-3 menu-item"
        data-id="7" data-cat="tambahan">

        <div class="menu-card d-flex flex-column">

          <div class="menu-img">
            <img
              src="https://images.unsplash.com/photo-1544025162-d76694265947"
              alt="Pangsit Goreng"
              loading="lazy">
          </div>

          <div class="p-3 d-flex flex-column flex-grow-1">

            <h5 class="fw-bold">Pangsit Goreng</h5>

            <p>
              Pangsit renyah isi ayam, cocok sebagai tambahan bakso.
            </p>

            <div class="d-flex justify-content-between align-items-center mt-auto">
              <span class="price">Rp 8.000</span>
              <div class="qty-slot"></div>
            </div>

          </div>
        </div>
      </div>


      <!-- MENU 8: TAHU BAKSO -->
      <div class="col-sm-6 col-lg-4 col-xl-3 menu-item"
        data-id="8" data-cat="tambahan">

        <div class="menu-card d-flex flex-column">

          <div class="menu-img">
            <img
              src="https://images.unsplash.com/photo-1547592180-85f173990554"
              alt="Tahu Bakso"
              loading="lazy">
          </div>

          <div class="p-3 d-flex flex-column flex-grow-1">

            <h5 class="fw-bold">Tahu Bakso</h5>

            <p>
              Tahu isi daging bakso yang gurih dan lezat.
            </p>

            <div class="d-flex justify-content-between align-items-center mt-auto">
              <span class="price">Rp 7.000</span>
              <div class="qty-slot"></div>
            </div>

          </div>
        </div>
      </div>


      <!-- MENU 9: KERUPUK BAKSO -->
      <div class="col-sm-6 col-lg-4 col-xl-3 menu-item"
        data-id="9" data-cat="tambahan">

        <div class="menu-card d-flex flex-column">

          <div class="menu-img">
            <img
              src="https://images.unsplash.com/photo-1626082927389-6cd097cdc6ec"
              alt="Kerupuk Bakso"
              loading="lazy">
          </div>

          <div class="p-3 d-flex flex-column flex-grow-1">

            <h5 class="fw-bold">Kerupuk Bakso</h5>

            <p>
              Kerupuk renyah untuk melengkapi semangkuk bakso.
            </p>

            <div class="d-flex justify-content-between align-items-center mt-auto">
              <span class="price">Rp 3.000</span>
              <div class="qty-slot"></div>
            </div>

          </div>
        </div>
      </div>


      <!-- MENU 10: ES TEH -->
      <div class="col-sm-6 col-lg-4 col-xl-3 menu-item"
        data-id="10" data-cat="minuman">

        <div class="menu-card d-flex flex-column">

          <div class="menu-img">
            <img
              src="https://images.unsplash.com/photo-1556679343-c7306c1976bc"
              alt="Es Teh Manis"
              loading="lazy">
          </div>

          <div class="p-3 d-flex flex-column flex-grow-1">

            <h5 class="fw-bold">Es Teh Manis</h5>

            <p>
              Teh dingin manis dan menyegarkan.
            </p>

            <div class="d-flex justify-content-between align-items-center mt-auto">
              <span class="price">Rp 5.000</span>
              <div class="qty-slot"></div>
            </div>

          </div>
        </div>
      </div>


      <!-- MENU 11: ES JERUK -->
      <div class="col-sm-6 col-lg-4 col-xl-3 menu-item"
        data-id="11" data-cat="minuman">

        <div class="menu-card d-flex flex-column">

          <div class="menu-img">
            <img
              src="https://images.unsplash.com/photo-1513558161293-cdaf765edfd4"
              alt="Es Jeruk"
              loading="lazy">
          </div>

          <div class="p-3 d-flex flex-column flex-grow-1">

            <h5 class="fw-bold">Es Jeruk</h5>

            <p>
              Jeruk peras asli dengan rasa asam manis.
            </p>

            <div class="d-flex justify-content-between align-items-center mt-auto">
              <span class="price">Rp 7.000</span>
              <div class="qty-slot"></div>
            </div>

          </div>
        </div>
      </div>


      <!-- MENU 12: TEH HANGAT -->
      <div class="col-sm-6 col-lg-4 col-xl-3 menu-item"
        data-id="12" data-cat="minuman">

        <div class="menu-card d-flex flex-column">

          <div class="menu-img">
            <img
              src="https://images.unsplash.com/photo-1571934811356-5cc061b6821f"
              alt="Teh Hangat"
              loading="lazy">
          </div>

          <div class="p-3 d-flex flex-column flex-grow-1">

            <h5 class="fw-bold">Teh Hangat</h5>

            <p>
              Teh hangat tawar atau manis.
            </p>

            <div class="d-flex justify-content-between align-items-center mt-auto">
              <span class="price">Rp 4.000</span>
              <div class="qty-slot"></div>
            </div>

          </div>
        </div>
      </div>

    </div>
  </div>
</section>


<!-- ===================================== -->
<!-- PESANAN -->
<!-- ===================================== -->

<section id="pesan" class="py-5 section-order">
  <div class="container py-4">

    <div class="text-center mb-5">

      <span class="section-tag light">Pesanan</span>

      <h2 class="section-title text-white">
        Pesan Lewat Ojek / Delivery
      </h2>

      <p class="text-white-50">
        Isi data pemesan, pilih cara pengantaran,
        lalu kirim pesanan lewat WhatsApp.
      </p>

    </div>

    <div class="row g-4">

      <!-- FORM PEMESANAN -->
      <div class="col-lg-7">

        <form id="orderForm" class="order-card" novalidate>

          <h4 class="mb-4">
            <i class="bi bi-person-lines-fill text-danger"></i>
            Data Pemesan
          </h4>

          <div class="mb-3">

            <label for="nama" class="form-label fw-bold">
              Nama Pemesan
            </label>

            <input
              type="text"
              class="form-control form-control-lg"
              id="nama"
              placeholder="Contoh: Budi Santoso"
              required>

            <div class="invalid-feedback">
              Nama pemesan wajib diisi.
            </div>

          </div>


          <div class="mb-3">

            <label for="hp" class="form-label fw-bold">
              Nomor WhatsApp / HP
            </label>

            <input
              type="tel"
              class="form-control form-control-lg"
              id="hp"
              placeholder="08xxxxxxxxxx"
              pattern="[0-9+\- ]{9,16}"
              required>

            <div class="invalid-feedback">
              Masukkan nomor HP yang valid.
            </div>

          </div>


          <!-- METODE PENGANTARAN -->
          <label class="form-label fw-bold">
            Metode Pengantaran
          </label>

          <div class="row g-3 mb-3" id="methods">

            <div class="col-md-4">

              <input
                type="radio"
                class="btn-check"
                name="metode"
                id="m-ojek"
                value="ojek"
                checked>

              <label class="method-box" for="m-ojek">
                <i class="bi bi-scooter"></i>
                <b>Ojek Online</b>
                <small>Gojek / Grab, ongkir bayar ke driver</small>
              </label>

            </div>


            <div class="col-md-4">

              <input
                type="radio"
                class="btn-check"
                name="metode"
                id="m-delivery"
                value="delivery">

              <label class="method-box" for="m-delivery">
                <i class="bi bi-truck"></i>
                <b>Delivery Pak Ran</b>
                <small>Kurir kami, Rp 8.000 (gratis ≥ Rp 100.000)</small>
              </label>

            </div>


            <div class="col-md-4">

              <input
                type="radio"
                class="btn-check"
                name="metode"
                id="m-ambil"
                value="ambil">

              <label class="method-box" for="m-ambil">
                <i class="bi bi-shop"></i>
                <b>Ambil Sendiri</b>
                <small>Ambil di warung, tanpa ongkir</small>
              </label>

            </div>

          </div>


          <!-- ALAMAT -->
          <div class="mb-3" id="alamatWrap">

            <label for="alamat" class="form-label fw-bold">
              Alamat Pengantaran
            </label>

            <textarea
              class="form-control"
              id="alamat"
              rows="3"
              placeholder="Nama jalan, nomor rumah, RT/RW, patokan"></textarea>

            <div class="invalid-feedback">
              Alamat wajib diisi untuk ojek / delivery.
            </div>

          </div>


          <!-- CATATAN -->
          <div class="mb-4">

            <label for="catatan" class="form-label fw-bold">
              Catatan (opsional)
            </label>

            <input
              type="text"
              class="form-control"
              id="catatan"
              placeholder="Contoh: sambal dipisah, tanpa seledri">

          </div>


          <button type="submit" class="btn btn-danger btn-lg w-100 rounded-pill fw-bold">
            <i class="bi bi-whatsapp"></i>
            Kirim Pesanan
          </button>

        </form>
      </div>


      <!-- RINGKASAN PESANAN -->
      <div class="col-lg-5">

        <div class="order-card sticky-lg-top" style="top:90px">

          <h4 class="mb-3">
            <i class="bi bi-cart3 text-danger"></i>
            Ringkasan Pesanan
          </h4>

          <div id="cartEmpty" class="text-center text-muted py-4">

            <i class="bi bi-cart-x" style="font-size:3rem"></i>

            <p class="mb-0">
              Belum ada pesanan. Pilih menu dulu ya!
            </p>

          </div>

          <ul class="list-group list-group-flush mb-3" id="cartList"></ul>

          <div id="cartTotals" class="d-none">

            <div class="d-flex justify-content-between">
              <span>Subtotal</span>
              <b id="subtotal">Rp 0</b>
            </div>

            <div class="d-flex justify-content-between">
              <span>Ongkir</span>
              <b id="ongkir">Rp 0</b>
            </div>

            <hr>

            <div class="d-flex justify-content-between fs-5">
              <span>Total</span>
              <b class="text-danger" id="total">Rp 0</b>
            </div>

            <button class="btn btn-outline-secondary btn-sm mt-3" id="clearCart">
              <i class="bi bi-trash"></i>
              Kosongkan
            </button>

          </div>

        </div>
      </div>

    </div>
  </div>
</section>


<!-- ===================================== -->
<!-- FOOTER -->
<!-- ===================================== -->

<footer class="footer">

  <div class="container py-5">

    <div class="row g-4">

      <!-- BRAND -->
      <div class="col-lg-4">

        <div class="brand fs-3 mb-2">
          Bakso <span>Pak Ran</span>
        </div>

        <p class="mb-3">
          Bakso hangat, kenyal, dan nikmat.
          Mengutamakan kualitas, kejujuran,
          serta keberkahan dalam berdagang.
        </p>

        <div class="d-flex gap-2">

          <a href="#" class="social" aria-label="Instagram">
            <i class="bi bi-instagram"></i>
          </a>

          <a href="#" class="social" aria-label="Facebook">
            <i class="bi bi-facebook"></i>
          </a>

          <a href="#" class="social" aria-label="TikTok">
            <i class="bi bi-tiktok"></i>
          </a>

          <a href="#" class="social" aria-label="WhatsApp">
            <i class="bi bi-whatsapp"></i>
          </a>

        </div>
      </div>


      <!-- NAVIGASI -->
      <div class="col-6 col-lg-2">

        <h6>Navigasi</h6>

        <ul class="list-unstyled">
          <li><a href="#home">Home</a></li>
          <li><a href="#about">Tentang Makanan</a></li>
          <li><a href="#menu">Menu</a></li>
          <li><a href="#pesan">Pesanan</a></li>
        </ul>

      </div>


      <!-- JAM BUKA -->
      <div class="col-6 col-lg-3">

        <h6>Jam Buka</h6>

        <ul class="list-unstyled">
          <li>Senin – Jumat: 09.00 – 21.00</li>
          <li>Sabtu – Minggu: 08.00 – 22.00</li>
        </ul>

      </div>


      <!-- KONTAK -->
      <div class="col-lg-3">

        <h6>Kontak</h6>

        <ul class="list-unstyled">

          <li>
            <i class="bi bi-geo-alt-fill"></i>
            Jl. Contoh No. 123, Indonesia
          </li>

          <li>
            <i class="bi bi-telephone-fill"></i>
            0812-3456-7890
          </li>

          <li>
            <i class="bi bi-envelope-fill"></i>
            halo@baksopakran.id
          </li>

        </ul>

      </div>

    </div>
  </div>

  <div class="container text-center pb-3 photo-credit">
    <small>
      Foto bakso digunakan sebagai foto ilustrasi,
      bukan dokumentasi khusus Bakso Pak Ran.
    </small>
  </div>

  <div class="footer-bottom text-center py-3">
    © <span id="year"></span> Bakso Pak Ran. Semua hak dilindungi.
  </div>

</footer>


<!-- ===================================== -->
<!-- MODAL KONFIRMASI -->
<!-- ===================================== -->

<div class="modal fade" id="doneModal" tabindex="-1" aria-hidden="true">

  <div class="modal-dialog modal-dialog-centered">

    <div class="modal-content rounded-4 border-0">

      <div class="modal-body text-center p-4">

        <i class="bi bi-check-circle-fill text-success" style="font-size:4rem"></i>

        <h4 class="fw-bold">
          Terima kasih, <span id="doneNama"></span>!
        </h4>

        <p class="text-muted">
          Pesananmu sudah disiapkan. Tekan tombol di bawah
          untuk mengirim detail pesanan ke Pak Ran lewat WhatsApp.
        </p>

        <pre class="receipt text-start" id="receipt"></pre>

        <div class="d-grid gap-2">

          <a href="#"
            target="_blank"
            rel="noopener"
            class="btn btn-success rounded-pill fw-bold"
            id="waLink">

            <i class="bi bi-whatsapp"></i>
            Buka WhatsApp

          </a>

          <button class="btn btn-light rounded-pill" data-bs-dismiss="modal">
            Tutup
          </button>

        </div>

      </div>
    </div>
  </div>
</div>


<!-- ===================================== -->
<!-- TOAST / NOTIFIKASI -->
<!-- ===================================== -->

<div class="toast-container position-fixed bottom-0 end-0 p-3">

  <div id="toast" class="toast align-items-center text-bg-success border-0" role="status">

    <div class="d-flex">

      <div class="toast-body" id="toastMsg"></div>

      <button type="button"
        class="btn-close btn-close-white me-2 m-auto"
        data-bs-dismiss="toast">
      </button>

    </div>
  </div>
</div>


<!-- ===================================== -->
<!-- JAVASCRIPT BOOTSTRAP -->
<!-- ===================================== -->

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

<!-- JAVASCRIPT MENU DAN PESANAN -->
<script src="script.js"></script>

</body>
</html>