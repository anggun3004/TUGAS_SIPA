// ===== PENGATURAN =====
const WA_NUMBER = '6281234567890';
const DELIVERY_FEE = 8000;
const FREE_DELIVERY_MIN = 100000;
// === MENU ====

// ===== DATA MENU BAKSO PAK RAN =====
const MENU = [
  {
    id: 1,
    name: 'Bakso Urat Jumbo',
    price: 20000,
    cat: 'bakso',
    foto: 'images/bakso.jpg',
    desc: 'Bakso besar isi urat sapi, kenyal dan gurih.',
    tag: 'Best Seller'
  },
  {
    id: 2,
    name: 'Bakso Beranak',
    price: 25000,
    cat: 'bakso',
    foto: 'images/bakso.jpg',
    desc: 'Bakso besar dengan isian bakso kecil.',
    tag: 'Favorit'
  },
  {
    id: 3,
    name: 'Bakso Mercon',
    price: 22000,
    cat: 'bakso',
    foto: 'images/bakso.jpg',
    desc: 'Bakso pedas dengan isian cabai yang nikmat.',
    tag: 'Pedas'
  },
  {
    id: 4,
    name: 'Bakso Telur',
    price: 18000,
    cat: 'bakso',
    foto: 'images/bakso.jpg',
    desc: 'Bakso isi telur dengan kuah gurih.',
    tag: ''
  },
  {
    id: 5,
    name: 'Bakso Halus Kuah',
    price: 15000,
    cat: 'bakso',
    foto: 'images/bakso.jpg',
    desc: 'Bakso halus dengan kuah kaldu hangat.',
    tag: ''
  },
  {
    id: 6,
    name: 'Mie Ayam Bakso',
    price: 20000,
    cat: 'bakso',
    foto: 'images/bakso.jpg',
    desc: 'Mie ayam lezat dengan tambahan bakso.',
    tag: ''
  },
  {
    id: 7,
    name: 'Pangsit Goreng',
    price: 8000,
    cat: 'tambahan',
    foto: 'images/bakso.jpg',
    desc: 'Pangsit goreng renyah dan gurih.',
    tag: ''
  },
  {
    id: 8,
    name: 'Tahu Bakso',
    price: 7000,
    cat: 'tambahan',
    foto: 'images/bakso.jpg',
    desc: 'Tahu dengan isian adonan bakso.',
    tag: ''
  },
  {
    id: 9,
    name: 'Kerupuk Bakso',
    price: 3000,
    cat: 'tambahan',
    foto: 'images/bakso.jpg',
    desc: 'Kerupuk renyah sebagai pelengkap.',
    tag: ''
  },
  {
    id: 10,
    name: 'Es Teh Manis',
    price: 5000,
    cat: 'minuman',
    foto: 'images/bakso.jpg',
    desc: 'Es teh manis yang menyegarkan.',
    tag: ''
  },
  {
    id: 11,
    name: 'Es Jeruk',
    price: 7000,
    cat: 'minuman',
    foto: 'images/bakso.jpg',
    desc: 'Minuman jeruk segar.',
    tag: ''
  },
  {
    id: 12,
    name: 'Teh Hangat',
    price: 4000,
    cat: 'minuman',
    foto: 'images/bakso.jpg',
    desc: 'Teh hangat untuk menemani makan.',
    tag: ''
  }
];


function renderMenu() {
  document.querySelectorAll('.menu-item').forEach(card => {
    const id = Number(card.dataset.id);
    const menu = MENU.find(item => item.id === id);

    if (!menu) return;

    card.style.display =
      activeCat === 'semua' || menu.cat === activeCat ? '' : 'none';

    const slot = card.querySelector('.qty-slot');

    if (slot) {
      slot.innerHTML = qtyControl(id);
    }
  });
}


// ===== STATE =====
let cart = {};
let activeCat = 'semua';

const rp = n => 'Rp ' + n.toLocaleString('id-ID');
const $ = s => document.querySelector(s);

// ===== RENDER MENU =====
function renderMenu() {
  const list = MENU.filter(m =>
    activeCat === 'semua' || m.cat === activeCat
  );

  $('#menuList').innerHTML = list.map(m => `
    <div class="col-sm-6 col-lg-4 col-xl-3">
      <div class="menu-card d-flex flex-column">

        <div class="menu-img">
          <img src="${m.foto}" alt="${m.name}" loading="lazy">
          ${m.tag ? `<span class="menu-tag">${m.tag}</span>` : ''}
        </div>

        <div class="p-3 d-flex flex-column flex-grow-1">
          <h5 class="fw-bold mb-1">${m.name}</h5>
          <p>${m.desc}</p>

          <div class="d-flex justify-content-between align-items-center mt-auto">
            <span class="price">${rp(m.price)}</span>
            ${qtyControl(m.id)}
          </div>
        </div>

      </div>
    </div>
  `).join('');
}

// ===== TOMBOL JUMLAH =====
function qtyControl(id) {
  const q = cart[id] || 0;

  if (!q) {
    return `
      <button class="btn btn-danger rounded-pill fw-bold btn-sm px-3"
        data-add="${id}">
        <i class="bi bi-plus-lg"></i> Tambah
      </button>
    `;
  }

  return `
    <div class="qty">
      <button data-minus="${id}">−</button>
      <span>${q}</span>
      <button data-add="${id}">+</button>
    </div>
  `;
}

// ===== KERANJANG =====
function changeQty(id, delta) {
  cart[id] = (cart[id] || 0) + delta;

  if (cart[id] <= 0) {
    delete cart[id];
  }

  if (delta > 0) {
    toast('Ditambahkan: ' + MENU.find(m => m.id === id).name);
  }

  renderMenu();
  renderCart();
}

function getMethod() {
  return document.querySelector('input[name="metode"]:checked').value;
}

// ===== HITUNG TOTAL =====
function calc() {
  const subtotal = Object.entries(cart).reduce((s, [id, q]) => {
    return s + MENU.find(m => m.id == id).price * q;
  }, 0);

  const method = getMethod();
  let ongkir = 0;

  if (method === 'delivery' &&
      subtotal > 0 &&
      subtotal < FREE_DELIVERY_MIN) {
    ongkir = DELIVERY_FEE;
  }

  return {
    subtotal,
    ongkir,
    total: subtotal + ongkir,
    method
  };
}

// ===== TAMPILKAN KERANJANG =====
function renderCart() {
  const ids = Object.keys(cart);

  const count = ids.reduce((s, id) => s + cart[id], 0);

  $('#navCount').textContent = count;

  $('#cartEmpty').classList.toggle('d-none', ids.length > 0);
  $('#cartTotals').classList.toggle('d-none', ids.length === 0);

  $('#cartList').innerHTML = ids.map(id => {
    const m = MENU.find(x => x.id == id);

    return `
      <li class="list-group-item d-flex justify-content-between align-items-center">

        <div>
          <div class="fw-bold">${m.name}</div>
          <small class="text-muted">
            ${rp(m.price)} × ${cart[id]}
          </small>
        </div>

        <div class="d-flex align-items-center gap-2">

          <div class="qty">
            <button data-minus="${id}">−</button>
            <span>${cart[id]}</span>
            <button data-add="${id}">+</button>
          </div>

          <b>${rp(m.price * cart[id])}</b>

        </div>
      </li>
    `;
  }).join('');

  const { subtotal, ongkir, total, method } = calc();

  $('#subtotal').textContent = rp(subtotal);

  $('#ongkir').textContent =
    method === 'ojek'
      ? 'Sesuai tarif ojol'
      : (ongkir ? rp(ongkir) : 'Gratis');

  $('#total').textContent = rp(total);
}

// ===== EVENT MENU =====
document.addEventListener('click', e => {
  const add = e.target.closest('[data-add]');
  const minus = e.target.closest('[data-minus]');

  if (add) {
    changeQty(+add.dataset.add, 1);
  }

  if (minus) {
    changeQty(+minus.dataset.minus, -1);
  }
});

// ===== FILTER MENU =====
$('#filters').addEventListener('click', e => {
  const b = e.target.closest('.btn-filter');

  if (!b) return;

  document.querySelectorAll('.btn-filter').forEach(x => {
    x.classList.remove('active');
  });

  b.classList.add('active');
  activeCat = b.dataset.cat;

  renderMenu();
});

// ===== KOSONGKAN KERANJANG =====
$('#clearCart').addEventListener('click', () => {
  cart = {};
  renderMenu();
  renderCart();
});

// ===== METODE PENGANTARAN =====
document.querySelectorAll('input[name="metode"]').forEach(r => {
  r.addEventListener('change', () => {
    $('#alamatWrap').classList.toggle(
      'd-none',
      getMethod() === 'ambil'
    );

    renderCart();
  });
});

// ===== KIRIM PESANAN WHATSAPP =====
$('#orderForm').addEventListener('submit', e => {
  e.preventDefault();

  const nama = $('#nama');
  const hp = $('#hp');
  const alamat = $('#alamat');

  const method = getMethod();

  nama.classList.toggle('is-invalid', !nama.value.trim());

  hp.classList.toggle(
    'is-invalid',
    !/^[0-9+\- ]{9,16}$/.test(hp.value.trim())
  );

  alamat.classList.toggle(
    'is-invalid',
    method !== 'ambil' && !alamat.value.trim()
  );

  if (document.querySelector('#orderForm .is-invalid')) {
    return;
  }

  if (!Object.keys(cart).length) {
    toast('Pilih menu dulu sebelum memesan ya!', true);
    location.hash = '#menu';
    return;
  }

  const { subtotal, ongkir, total } = calc();

  const metodeText = {
    ojek: 'Ojek Online (Gojek/Grab)',
    delivery: 'Delivery Pak Ran',
    ambil: 'Ambil Sendiri'
  }[method];

  const items = Object.keys(cart).map(id => {
    const m = MENU.find(x => x.id == id);
    return `- ${m.name} x${cart[id]} = ${rp(m.price * cart[id])}`;
  }).join('\n');

  const ongkirText =
    method === 'ojek'
      ? 'Sesuai tarif ojol'
      : (ongkir ? rp(ongkir) : 'Gratis');

  const catatan = $('#catatan').value.trim();

  const text =
`*PESANAN BAKSO PAK RAN*

Nama: ${nama.value.trim()}
HP: ${hp.value.trim()}
Metode: ${metodeText}
${method !== 'ambil' ? 'Alamat: ' + alamat.value.trim() + '\n' : ''}
*Pesanan:*
${items}

Subtotal: ${rp(subtotal)}
Ongkir: ${ongkirText}
*Total: ${rp(total)}*
${catatan ? '\nCatatan: ' + catatan : ''}`;

  $('#doneNama').textContent = nama.value.trim();
  $('#receipt').textContent = text.replace(/\*/g, '');

  const url = `https://wa.me/${WA_NUMBER}?text=${encodeURIComponent(text)}`;

  $('#waLink').href = url;

  new bootstrap.Modal($('#doneModal')).show();
});

// ===== TOAST =====
function toast(msg, warn = false) {
  const t = $('#toast');

  t.classList.toggle('text-bg-success', !warn);
  t.classList.toggle('text-bg-warning', warn);

  $('#toastMsg').textContent = msg;

  bootstrap.Toast.getOrCreateInstance(t, {
    delay: 1800
  }).show();
}

// ===== INIT =====
$('#year').textContent = new Date().getFullYear();

renderMenu();
renderCart();