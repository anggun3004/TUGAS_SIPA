<div
  class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom"
>
  <h1 class="h2">Tambah Product</h1>
</div>

<form action="prosesaddproduk.php" method="post" enctype="multipart/form-data">

    <div class="mb-3">
        <label for="" class="form-label">Nama Produk</label>
        <input name="namaproduk" type="text" class="form-control" id="" placeholder="">
    </div>

    <div class="mb-3">
        <label for="" class="form-label">Harga</label>
        <input name="harga" type="number" class="form-control" id="" placeholder="">
    </div>

    <div class="mb-3">
        <label for="" class="form-label">Stok</label>
        <input name="stok" type="number" class="form-control" id="" placeholder="">
    </div>

    <div class="mb-3">
        <label for="" class="form-label">Kategori</label>
        <input name="kategori" type="text" class="form-control" id="" placeholder="">
    </div>

    <div class="mb-3">
        <label for="" class="form-label">Gambar</label>
        <input name="gambar" type="file" class="form-control" id="">
    </div>

    <button type="submit" name="simpan" class="btn btn-primary">Simpan</button>

</form>