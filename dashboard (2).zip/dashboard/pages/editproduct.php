<?php
include 'pages/koneksi.php';

$id = $_GET['id'];

$query = "SELECT * FROM produk WHERE id = '$id'";
$result = mysqli_query($connect, $query);
$row = mysqli_fetch_assoc($result);
?>

<h2>Edit Produk</h2>

<form action="prosesedit.php" method="post">

    <input type="hidden" name="id" value="<?php echo $row['id']; ?>">

    <div class="mb-3">
        <label>Nomor #</label>
        <input type="text" class="form-control"
        value="<?php echo $row['id']; ?>" readonly>
    </div>

    <div class="mb-3">
        <label>Nama Produk</label>
        <input type="text" name="nama_produk" class="form-control"
        value="<?php echo $row['nama_produk']; ?>">
    </div>

    <div class="mb-3">
        <label>Harga</label>
        <input type="number" name="harga" class="form-control"
        value="<?php echo $row['harga']; ?>">
    </div>

    <div class="mb-3">
        <label>Stok</label>
        <input type="number" name="stok" class="form-control"
        value="<?php echo $row['stok']; ?>">
    </div>

    <div class="mb-3">
        <label>Kategori</label>
        <input type="text" name="kategori" class="form-control"
        value="<?php echo $row['kategori']; ?>">
    </div>

    <div class="mb-3">
        <label>Gambar</label>
        <input type="text" name="gambar" class="form-control"
        value="<?php echo $row['gambar']; ?>">
    </div>

    <button type="submit" name="simpan" class="btn btn-primary">
        Simpan Perubahan
    </button>

    <a href="index.php?pages=products" class="btn btn-secondary">
        Kembali
    </a>

</form>