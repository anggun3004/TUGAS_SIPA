<?php
$host = "localhost";
$username = "root";
$password = "";
$database = "dashboard";

$connect = mysqli_connect($host, $username, $password, $database);

if (!$connect) {
    die("Koneksi gagal: " . mysqli_connect_error());
}

mysqli_set_charset($connect, "utf8mb4");
?>