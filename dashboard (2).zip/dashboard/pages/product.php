<?php
include 'koneksi.php';

$query  = "SELECT * FROM produk";
$result = mysqli_query($connect, $query);
?>

<div
  class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom"
>
  <h1 class="h2">Product</h1>
</div>

<h2>Halaman Produk</h2>

<div class="mb-4 mb-md-0">
  <a href="index.php?pages=addproduct" class="btn btn-sm btn-outline-danger">
    Tambah Produk
  </a>
</div>

<br>

<div class="table-responsive small">
  <table class="table table-striped table-sm">
    <thead>
      <tr>
        <th scope="col">Nomor</th>
        <th scope="col">#</th>
        <th scope="col">Nama Produk</th>
        <th scope="col">Harga</th>
        <th scope="col">Stok</th>
        <th scope="col">Kategori</th>
        <th scope="col">Gambar</th>
        <th scope="col">Aksi</th>
      </tr>
    </thead>

    <tbody>
      <?php $no = 1; ?>

      <?php while ($row = mysqli_fetch_assoc($result)) { ?>
        <tr>
          <td><?php echo $no++; ?></td>
          <td><?php echo $row['id']; ?></td>
          <td><?php echo $row['nama_produk']; ?></td>
          <td><?php echo $row['harga']; ?></td>
          <td><?php echo $row['stok']; ?></td>
          <td><?php echo $row['kategori']; ?></td>
          <td><?php echo $row['gambar']; ?></td>

          <td>
            <a href="index.php?pages=editproduct&id=<?php echo $row['id']; ?>"
               class="btn btn-info">Edit</a>

            <form action="proseshapus.php" method="post" class="d-inline">
              <input type="hidden" name="id" value="<?php echo $row['id']; ?>">

              <button type="submit" name="hapus" class="btn btn-warning"
                onclick="return confirm('Yakin ingin menghapus produk ini?')">
                Hapus
              </button>
            </form>
          </td>
        </tr>
      <?php } ?>

    </tbody>
  </table>
</div>